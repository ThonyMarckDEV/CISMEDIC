// src/js/urlHelper.js

const API_BASE_URL_PHOTO = 'https://clinicacismedic.com';


export default API_BASE_URL_PHOTO

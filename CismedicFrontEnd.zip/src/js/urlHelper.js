// src/js/urlHelper.js

const API_BASE_URL = 'https://clinicacismedic.com/backend/public';


export default API_BASE_URL
